import React from 'react';

export const Hero: React.FC = () => {
  return (
    <div className="text-center max-w-2xl mx-auto pt-8">
      <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 dark:text-slate-50 mb-6 leading-tight transition-colors">
        O Doutor das suas <span className="text-green-600 dark:text-green-500">Plantas e Hortaliças</span>
      </h1>
      <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 leading-relaxed transition-colors">
        Tire uma foto e descubra instantaneamente o que está afetando suas plantas, hortas e pomares.
        Receba diagnósticos precisos e tratamentos recomendados.
      </p>
    </div>
  );
};