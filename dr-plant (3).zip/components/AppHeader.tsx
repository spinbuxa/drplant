// Deprecated: Use Navbar.tsx instead
export const AppHeader = () => null;