import React from 'react';
import { Sprout, Moon, Sun, Bell } from 'lucide-react';

interface SiteHeaderProps {
  onReset: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export const SiteHeader: React.FC<SiteHeaderProps> = ({ onReset, isDarkMode, toggleTheme }) => {
  return (
    <nav className="bg-green-600 dark:bg-green-800 text-white sticky top-0 z-50 shadow-md transition-colors duration-300">
      <div className="container mx-auto px-4 h-14 flex items-center justify-between">
        <button 
          onClick={onReset} 
          className="flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center backdrop-blur-sm">
            <Sprout size={20} className="text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">Dr Plant</span>
        </button>
        
        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors relative">
            <Bell size={20} />
            <span className="absolute top-2 right-2 w-2 h-2 bg-red-400 rounded-full border border-green-600"></span>
          </button>
          
          <button 
            onClick={toggleTheme}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </nav>
  );
};