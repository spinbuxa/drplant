// Deprecated: Use Navbar.tsx instead
export const Header = () => null;
export default Header;