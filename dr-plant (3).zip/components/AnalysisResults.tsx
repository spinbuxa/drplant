import React, { useState, useEffect } from 'react';
import { PlantAnalysisResult } from '../types';
import { 
  AlertCircle, CheckCircle, Leaf, Shield, TestTube, AlertTriangle, 
  Sprout, Info, ThermometerSun, Bug, Droplet, Search, Plus, Share2, 
  Check, FileText, Save, ArrowRight, FileQuestion 
} from 'lucide-react';

interface AnalysisResultsProps {
  result: PlantAnalysisResult;
  onSave?: (result: PlantAnalysisResult) => void;
  isSaved?: boolean;
  onUpdateNotes?: (id: string, notes: string) => void;
}

export const AnalysisResults: React.FC<AnalysisResultsProps> = ({ result, onSave, isSaved = false, onUpdateNotes }) => {
  const [copyFeedback, setCopyFeedback] = useState(false);
  const [noteText, setNoteText] = useState(result.userNotes || '');
  const [isSavingNote, setIsSavingNote] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'treatment' | 'culture'>('overview');

  useEffect(() => {
    setNoteText(result.userNotes || '');
    setIsSavingNote(false);
    setActiveTab('overview');
  }, [result.id, result.userNotes]);

  const handleSaveNote = () => {
    if (onUpdateNotes) {
      onUpdateNotes(result.id, noteText);
      setIsSavingNote(true);
      setTimeout(() => setIsSavingNote(false), 2000);
    }
  };

  if (!result.isPlant) {
    return (
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-6 text-center animate-fade-in transition-colors mt-4">
        <FileQuestion className="w-12 h-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-amber-800 dark:text-amber-200 mb-2">Planta não detectada</h3>
        <p className="text-amber-700 dark:text-amber-300">{result.description}</p>
        <p className="text-sm text-amber-600 dark:text-amber-400 mt-4">Por favor, tente enviar uma foto clara de uma folha, caule ou fruto.</p>
      </div>
    );
  }

  const isHealthy = result.diagnosis.toLowerCase().includes('saudável') || result.diagnosis.toLowerCase().includes('healthy');

  const handleShare = async () => {
    const shareText = `Dr Plant Diagnóstico: ${result.diagnosis}\n\n${result.description}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: `Dr Plant: ${result.diagnosis}`, text: shareText });
      } catch (err) { console.log('Error sharing:', err); }
    } else {
      try {
        await navigator.clipboard.writeText(shareText);
        setCopyFeedback(true);
        setTimeout(() => setCopyFeedback(false), 2000);
      } catch (err) { alert('Compartilhamento não suportado neste dispositivo.'); }
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-24">
      {/* Diagnosis Header Card */}
      <div className={`
        rounded-2xl p-6 border shadow-sm transition-colors duration-300 relative overflow-hidden
        ${isHealthy 
          ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 dark:from-green-900/20 dark:to-emerald-900/20 dark:border-green-800' 
          : 'bg-gradient-to-br from-red-50 to-orange-50 border-red-200 dark:from-red-900/20 dark:to-orange-900/20 dark:border-red-800'
        }
      `}>
        {/* Confidence Badge */}
        <div className="absolute top-4 right-4">
           <div className={`
            px-3 py-1 rounded-full text-xs font-bold border shadow-sm backdrop-blur-sm
            ${isHealthy 
              ? 'bg-green-100/80 text-green-800 border-green-200 dark:bg-green-800/80 dark:text-green-100 dark:border-green-700' 
              : 'bg-red-100/80 text-red-800 border-red-200 dark:bg-red-800/80 dark:text-red-100 dark:border-red-700'
            }
          `}>
            {Math.round(result.confidence)}% Confiança
          </div>
        </div>

        <div className="mt-2">
            <div className="flex items-center gap-2 mb-3">
              {isHealthy ? (
                <CheckCircle className="text-green-600 dark:text-green-400" size={28} />
              ) : (
                <AlertCircle className="text-red-600 dark:text-red-400" size={28} />
              )}
              <span className={`font-bold text-sm tracking-widest uppercase opacity-80 ${isHealthy ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'}`}>
                Diagnóstico
              </span>
            </div>
            
            <h2 className={`text-3xl font-extrabold leading-tight ${isHealthy ? 'text-green-900 dark:text-green-100' : 'text-red-900 dark:text-red-100'}`}>
              {result.diagnosis}
            </h2>
            
            {result.scientificName && (
              <p className={`italic mt-1 text-sm font-medium opacity-80 ${isHealthy ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}`}>
                {result.scientificName}
              </p>
            )}
        </div>

        {/* Action Buttons Row */}
        <div className="flex gap-3 mt-6">
            {onSave && (
              <button 
                onClick={() => onSave(result)}
                disabled={isSaved}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm shadow-sm transition-all active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed
                ${isSaved
                  ? 'bg-slate-200/50 text-slate-500 border border-slate-200 shadow-none dark:bg-slate-700/50 dark:text-slate-400 dark:border-slate-600'
                  : 'bg-white text-slate-800 hover:bg-slate-50 border border-slate-200 dark:bg-slate-800 dark:text-white dark:border-slate-700'
                }`}
              >
                {isSaved ? <Check size={18} /> : <Plus size={18} />}
                {isSaved ? 'Salvo' : 'Salvar'}
              </button>
            )}
            
            <button 
              onClick={handleShare}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold text-sm bg-white text-slate-800 hover:bg-slate-50 border border-slate-200 shadow-sm transition-all active:scale-95 dark:bg-slate-800 dark:text-white dark:border-slate-700"
            >
              {copyFeedback ? <CheckCircle size={18} className="text-green-500" /> : <Share2 size={18} />}
              {copyFeedback ? 'Copiado' : 'Compartilhar'}
            </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mx-1">
        {[
          { id: 'overview', label: 'Visão Geral', icon: Info },
          { id: 'treatment', label: 'Tratamento', icon: TestTube },
          { id: 'culture', label: 'Sobre a Planta', icon: Sprout },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id 
                ? 'bg-white dark:bg-slate-700 text-green-600 dark:text-green-400 shadow-sm' 
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
            }`}
          >
            <tab.icon size={16} />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="animate-fade-in min-h-[300px]">
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Description */}
            <div className="bg-white dark:bg-slate-800 rounded-xl p-5 border border-slate-100 dark:border-slate-700 shadow-sm">
               <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2">Análise</h3>
               <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                 {result.description}
               </p>
            </div>

            {/* Symptoms */}
            {!isHealthy && result.symptoms && result.symptoms.length > 0 && (
              <div className="bg-red-50 dark:bg-red-900/10 rounded-xl p-5 border border-red-100 dark:border-red-900/30">
                <h3 className="font-bold text-red-900 dark:text-red-200 mb-3 flex items-center gap-2">
                  <AlertTriangle size={18} /> Sintomas
                </h3>
                <ul className="space-y-2">
                  {result.symptoms.map((s, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300 text-sm">
                      <div className="w-1.5 h-1.5 bg-red-400 rounded-full mt-1.5 shrink-0"></div>
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Causes */}
            {result.causes && result.causes.length > 0 && (
               <div className="bg-amber-50 dark:bg-amber-900/10 rounded-xl p-5 border border-amber-100 dark:border-amber-900/30">
                 <h3 className="font-bold text-amber-900 dark:text-amber-200 mb-3 flex items-center gap-2">
                   <Search size={18} /> Causas Prováveis
                 </h3>
                 <ul className="space-y-2">
                   {result.causes.map((c, i) => (
                     <li key={i} className="flex items-start gap-2 text-slate-700 dark:text-slate-300 text-sm">
                       <Info size={14} className="text-amber-500 mt-0.5 shrink-0" />
                       {c}
                     </li>
                   ))}
                 </ul>
               </div>
            )}
          </div>
        )}

        {activeTab === 'treatment' && (
          <div className="space-y-4">
             {isHealthy ? (
               <div className="text-center py-10 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700">
                 <CheckCircle size={48} className="text-green-500 mx-auto mb-4" />
                 <h3 className="font-bold text-slate-800 dark:text-slate-100">Nenhum tratamento necessário</h3>
                 <p className="text-slate-500 dark:text-slate-400 mt-2 px-6">
                   Sua planta está saudável! Continue com os bons cuidados de rega e adubação.
                 </p>
               </div>
             ) : (
               <>
                 {/* Prevention First (Plantix style) */}
                 <div className="bg-indigo-50 dark:bg-indigo-900/10 rounded-xl p-5 border border-indigo-100 dark:border-indigo-900/30">
                    <h3 className="font-bold text-indigo-900 dark:text-indigo-200 mb-3 flex items-center gap-2">
                      <Shield size={18} /> Medidas Preventivas
                    </h3>
                    <ul className="space-y-3">
                      {result.treatment.prevention.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-slate-700 dark:text-slate-300 text-sm">
                          <Check size={16} className="text-indigo-500 mt-0.5 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                 </div>

                 {/* Biological */}
                 <div className="bg-white dark:bg-slate-800 rounded-xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm">
                    <h3 className="font-bold text-green-700 dark:text-green-400 mb-3 flex items-center gap-2">
                      <Leaf size={18} /> Controle Biológico
                    </h3>
                    {result.treatment.biological && result.treatment.biological.length > 0 ? (
                      <ul className="space-y-3">
                        {result.treatment.biological.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-sm">
                            <span className="w-5 h-5 rounded-full bg-green-100 dark:bg-green-900/50 text-green-600 flex items-center justify-center text-xs font-bold shrink-0">{idx + 1}</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-slate-400 italic text-sm">Nenhum tratamento biológico específico sugerido.</p>
                    )}
                 </div>

                 {/* Chemical */}
                 <div className="bg-white dark:bg-slate-800 rounded-xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm">
                    <h3 className="font-bold text-slate-700 dark:text-slate-300 mb-3 flex items-center gap-2">
                      <TestTube size={18} /> Controle Químico
                    </h3>
                    {result.treatment.chemical && result.treatment.chemical.length > 0 ? (
                      <ul className="space-y-3">
                        {result.treatment.chemical.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-slate-600 dark:text-slate-300 text-sm">
                            <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 flex items-center justify-center text-xs font-bold shrink-0">{idx + 1}</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-slate-400 italic text-sm">Nenhum tratamento químico sugerido.</p>
                    )}
                 </div>
               </>
             )}

             {/* Nutritional */}
             {result.nutritionalDeficiencies && result.nutritionalDeficiencies.length > 0 && (
                <div className="bg-yellow-50 dark:bg-yellow-900/10 rounded-xl p-5 border border-yellow-100 dark:border-yellow-900/30">
                   <h3 className="font-bold text-yellow-800 dark:text-yellow-200 mb-3 flex items-center gap-2">
                     <Droplet size={18} /> Correção Nutricional
                   </h3>
                   <ul className="space-y-3">
                     {result.nutritionalDeficiencies.map((def, idx) => (
                       <li key={idx} className="bg-white dark:bg-slate-800 p-3 rounded-lg border border-yellow-100 dark:border-yellow-900/20">
                         <span className="block font-semibold text-yellow-700 dark:text-yellow-500 text-sm mb-1">{def.name}</span>
                         <span className="block text-slate-600 dark:text-slate-300 text-sm">{def.solution}</span>
                       </li>
                     ))}
                   </ul>
                </div>
             )}
          </div>
        )}

        {activeTab === 'culture' && result.cultureInfo && (
          <div className="space-y-4">
             <div className="bg-white dark:bg-slate-800 rounded-xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-xl text-slate-800 dark:text-slate-100">{result.cultureInfo.commonName}</h3>
                    <p className="text-slate-500 dark:text-slate-400 italic text-sm">{result.cultureInfo.scientificName}</p>
                  </div>
                  <span className="px-2 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs rounded-md">
                    {result.cultureInfo.family}
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-4">
                  {result.cultureInfo.description}
                </p>
                
                <div className="grid grid-cols-2 gap-3 mt-4">
                   <div className="bg-blue-50 dark:bg-blue-900/10 p-3 rounded-lg">
                      <div className="flex items-center gap-1.5 mb-1">
                         <ThermometerSun size={14} className="text-blue-500" />
                         <span className="text-xs font-bold text-blue-700 dark:text-blue-300">Clima & Solo</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300">{result.cultureInfo.idealConditions.description}</p>
                   </div>
                   <div className="bg-blue-50 dark:bg-blue-900/10 p-3 rounded-lg">
                      <div className="flex items-center gap-1.5 mb-1">
                         <Droplet size={14} className="text-blue-500" />
                         <span className="text-xs font-bold text-blue-700 dark:text-blue-300">Rega & pH</span>
                      </div>
                      <p className="text-xs text-slate-600 dark:text-slate-300">
                        Umidade: {result.cultureInfo.idealConditions.humidity}<br/>
                        pH: {result.cultureInfo.idealConditions.ph}
                      </p>
                   </div>
                </div>
             </div>
             
             <div className="grid grid-cols-2 gap-4">
                <div className="bg-orange-50 dark:bg-orange-900/10 rounded-xl p-4 border border-orange-100 dark:border-orange-900/30">
                   <h4 className="font-bold text-orange-800 dark:text-orange-200 text-sm mb-2 flex items-center gap-1.5">
                     <Bug size={14} /> Pragas Comuns
                   </h4>
                   <ul className="space-y-1">
                     {result.cultureInfo.commonPests.slice(0, 4).map((p, i) => (
                       <li key={i} className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                         <span className="w-1 h-1 rounded-full bg-orange-400"></span>{p}
                       </li>
                     ))}
                   </ul>
                </div>
                <div className="bg-red-50 dark:bg-red-900/10 rounded-xl p-4 border border-red-100 dark:border-red-900/30">
                   <h4 className="font-bold text-red-800 dark:text-red-200 text-sm mb-2 flex items-center gap-1.5">
                     <AlertTriangle size={14} /> Doenças Comuns
                   </h4>
                   <ul className="space-y-1">
                     {result.cultureInfo.commonDiseases.slice(0, 4).map((d, i) => (
                       <li key={i} className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                         <span className="w-1 h-1 rounded-full bg-red-400"></span>{d}
                       </li>
                     ))}
                   </ul>
                </div>
             </div>
          </div>
        )}
      </div>

      {/* User Notes (Always visible at bottom if needed) */}
      {onUpdateNotes && activeTab === 'overview' && (
        <div className="mt-6 bg-white dark:bg-slate-800 rounded-xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm">
          <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-3 flex items-center gap-2">
            <FileText size={18} /> Minhas Notas
          </h3>
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Adicione observações sobre a evolução..."
            className="w-full h-24 p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm resize-none focus:ring-2 focus:ring-green-500 outline-none"
          />
          <div className="mt-2 flex justify-end">
             <button
                onClick={handleSaveNote}
                disabled={isSavingNote}
                className="text-xs font-semibold px-4 py-2 bg-slate-800 text-white dark:bg-slate-700 rounded-lg hover:opacity-90 transition-opacity"
             >
               {isSavingNote ? 'Salvo' : 'Salvar Nota'}
             </button>
          </div>
        </div>
      )}
    </div>
  );
};